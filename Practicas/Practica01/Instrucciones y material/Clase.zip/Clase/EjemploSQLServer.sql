/* DROP TABLE Alumno;
 DROP TABLE Calificacion;*/
 CREATE TABLE Alumno(
 numCuenta INT NOT NULL UNIQUE,
 apellido VARCHAR(30),
 nombre VARCHAR(30),
 domicilio VARCHAR(40)
 );
 
 CREATE TABLE Calificacion(
 numCuenta INT,
 fecha DATE,
 nota NUMERIC(4,2) NOT NULL
 );
 
 ALTER TABLE Alumno ADD CONSTRAINT alumno_pkey PRIMARY KEY (numCuenta);
 ALTER TABLE Calificacion ADD CONSTRAINT calificacion_fkey FOREIGN KEY (numCuenta)
REFERENCES Alumno(numCuenta) ON UPDATE CASCADE ON DELETE CASCADE;

 INSERT INTO Alumno values(23333333,'Acosta','Ana','Avellaneda 111');
 INSERT INTO Alumno values(24444444,'Bustos','Betina','Bulnes 222');
 INSERT INTO Alumno values(25555555,'Caseros','Carlos','Colon 333');
 INSERT INTO Alumno values(26666666,'Duarte','Daniel','Dinamarca 444');


 INSERT INTO Calificacion values(23333333,'10/05/2017',5.3);
 INSERT INTO Calificacion values(23333333,'15/07/2017',8.3);
 INSERT INTO Calificacion values(23333333,'20/09/2017',7.4);
 INSERT INTO Calificacion values(24444444,'10/05/2017',8.6);
 INSERT INTO Calificacion values(24444444,'15/07/2017',9.4);
 INSERT INTO Calificacion values(25555555,'10/05/2017',9);
 INSERT INTO Calificacion values(25555555,'15/07/2017',6);
 INSERT INTO Calificacion values(26666666,'10/05/2017',3.2);
 INSERT INTO Calificacion values(26666666,'15/07/2017',5.3);
 INSERT INTO Calificacion values(26666666,'20/09/2017',3.5);

 -- Creamos o reemplazamos una vista normal que muestre el numCuenta
 -- del Alumno y el promedio de sus Calificacion:
 CREATE VIEW vista_promedios 
 as select a.numCuenta,avg(nota) as promedio
  from Alumno a
  join Calificacion n
  on a.numCuenta=n.numCuenta
  group by a.numCuenta;

 -- Eliminamos la vista materializada "vm_promedios:
 drop view vm_promedios;

 -- Creamos una vista materializada que muestre el numCuenta
 -- del Alumno y el promedio de sus Calificacion en esta version de SQL Server
 -- las vistas materializadas las veremos como vistas indexadas:
 
CREATE VIEW vm_promedios WITH SCHEMABINDING
 AS 
 select a.numCuenta, sum(nota) as notas, count_big(*) as contar
  from dbo.Alumno a join dbo.Calificacion n
  on a.numCuenta=n.numCuenta
  group by a.numCuenta;

  /* la operaci�n de agregaci�n avg no es permitido para crear un indice */
  CREATE UNIQUE CLUSTERED INDEX vm_promedios1 ON
  dbo.vm_promedios(numCuenta);

  /* Creamos una vista ahora si con el promedio*/
  CREATE VIEW vm_promedios2 AS
  SELECT 
	v.numCuenta,
	v.notas/v.contar as promedio FROM vm_promedios v WITH (NOEXPAND);
 -- Consultamos ambas vistas:
 select *from vista_promedios;
 select *from vm_promedios2;
 -- El resultado es el mismo.

 -- Ahora agregamos algunas Calificacion:
 INSERT INTO Calificacion values(23333333,'12/10/2017',9);
 INSERT INTO Calificacion values(24444444,'12/10/2017',7.5);
 INSERT INTO Calificacion values(25555555,'12/10/2017',3);
 INSERT INTO Calificacion values(26666666,'12/10/2017',4);

-- Consultamos ambas vistas y comparamos los promedios:
 select *from vista_promedios;
 select *from vm_promedios2;
